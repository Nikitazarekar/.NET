﻿using DemoProject.Model;
using Microsoft.EntityFrameworkCore;

namespace DemoProject.Data
{
   
        public class AppDbContext : DbContext
        {
            private readonly DbContextOptions<AppDbContext> dbContext;

            public AppDbContext(DbContextOptions<AppDbContext> dbContext) : base(dbContext)
            {
            }

            public DbSet<Product> products { get; set; }
        }
    
}
